-- Backup Coex CRM — Schema
-- Data: 2026-07-15T04:54:38.081Z

CREATE TABLE IF NOT EXISTS accounts (
  id uuid,
  name text,
  owner_user_id uuid,
  created_at timestamptz,
  updated_at timestamptz,
  default_currency text,
  logo_url text,
  footer_text text,
  endereco text,
  cnpj text,
  phone text
);

CREATE TABLE IF NOT EXISTS profiles (
  id uuid,
  user_id uuid,
  full_name text,
  email text,
  avatar_url text,
  role text,
  created_at timestamptz,
  updated_at timestamptz,
  beta_features jsonb,
  account_id uuid,
  account_role text,
  system_role jsonb,
  permissions jsonb
);

CREATE TABLE IF NOT EXISTS channels (
  id uuid,
  account_id uuid,
  type text,
  name text,
  config jsonb,
  status text,
  is_active boolean,
  created_at timestamptz,
  updated_at timestamptz
);

CREATE TABLE IF NOT EXISTS whatsapp_config (
  id uuid,
  user_id uuid,
  phone_number_id text,
  waba_id text,
  access_token text,
  verify_token text,
  status text,
  connected_at timestamptz,
  created_at timestamptz,
  updated_at timestamptz,
  registered_at timestamptz,
  subscribed_apps_at timestamptz,
  last_registration_error jsonb,
  account_id uuid,
  channel_token uuid,
  display_phone text,
  name text
);

CREATE TABLE IF NOT EXISTS tags (
  id uuid,
  user_id uuid,
  name text,
  color text,
  created_at timestamptz,
  account_id uuid
);

CREATE TABLE IF NOT EXISTS custom_fields (
  id uuid,
  user_id uuid,
  field_name text,
  field_type text,
  field_options jsonb,
  created_at timestamptz,
  account_id uuid
);

CREATE TABLE IF NOT EXISTS pipeline_stages (
  id uuid,
  pipeline_id uuid,
  name text,
  position integer,
  color text,
  created_at timestamptz
);

CREATE TABLE IF NOT EXISTS deals (
  id uuid,
  user_id uuid,
  pipeline_id uuid,
  stage_id uuid,
  contact_id uuid,
  conversation_id uuid,
  title text,
  value integer,
  currency text,
  notes text,
  expected_close_date jsonb,
  status text,
  created_at timestamptz,
  updated_at timestamptz,
  assigned_to jsonb,
  account_id uuid,
  end_date jsonb,
  origin_address jsonb,
  destination_address jsonb,
  property_type jsonb,
  vistoria_id jsonb
);

CREATE TABLE IF NOT EXISTS contacts (
  id uuid,
  user_id uuid,
  phone text,
  name text,
  email jsonb,
  company jsonb,
  avatar_url jsonb,
  created_at timestamptz,
  updated_at timestamptz,
  account_id uuid,
  phone_normalized text,
  ig_id jsonb,
  messenger_psid jsonb,
  telegram_chat_id text,
  document jsonb,
  address jsonb
);

CREATE TABLE IF NOT EXISTS contact_tags (
  id uuid,
  contact_id uuid,
  tag_id uuid,
  created_at timestamptz
);

CREATE TABLE IF NOT EXISTS contact_custom_values (
  id uuid,
  contact_id uuid,
  custom_field_id uuid,
  value text,
  created_at timestamptz
);

CREATE TABLE IF NOT EXISTS contact_notes (
  id uuid,
  contact_id uuid,
  user_id uuid,
  note_text text,
  created_at timestamptz,
  account_id uuid
);

CREATE TABLE IF NOT EXISTS message_templates (
  id uuid,
  user_id uuid,
  name text,
  category text,
  language text,
  header_type jsonb,
  header_content jsonb,
  body_text text,
  footer_text text,
  buttons jsonb,
  status text,
  created_at timestamptz,
  updated_at timestamptz,
  sample_values jsonb,
  meta_template_id jsonb,
  rejection_reason jsonb,
  quality_score jsonb,
  header_handle jsonb,
  header_media_url jsonb,
  submission_error jsonb,
  last_submitted_at jsonb,
  account_id uuid
);

CREATE TABLE IF NOT EXISTS mailbox_templates (
  id integer,
  account_id uuid,
  title text,
  description text,
  body text,
  created_by uuid,
  is_public boolean,
  deleted boolean,
  created_at timestamptz,
  updated_at timestamptz
);

CREATE TABLE IF NOT EXISTS automations (
  id uuid,
  user_id uuid,
  name text,
  description jsonb,
  trigger_type text,
  trigger_config jsonb,
  is_active boolean,
  execution_count integer,
  last_executed_at jsonb,
  created_at timestamptz,
  updated_at timestamptz,
  account_id uuid
);

CREATE TABLE IF NOT EXISTS automation_steps (
  id uuid,
  automation_id uuid,
  parent_step_id jsonb,
  branch jsonb,
  step_type text,
  step_config jsonb,
  position integer,
  created_at timestamptz
);

CREATE TABLE IF NOT EXISTS flows (
  id uuid,
  user_id uuid,
  name text,
  description text,
  status text,
  trigger_type text,
  trigger_config jsonb,
  entry_node_id text,
  fallback_policy jsonb,
  execution_count integer,
  last_executed_at jsonb,
  created_at timestamptz,
  updated_at timestamptz,
  account_id uuid
);

CREATE TABLE IF NOT EXISTS flow_nodes (
  id uuid,
  flow_id uuid,
  node_key text,
  node_type text,
  config jsonb,
  position_x integer,
  position_y integer,
  created_at timestamptz
);

CREATE TABLE IF NOT EXISTS mailboxes (
  id integer,
  account_id uuid,
  title text,
  color text,
  imap_authorized boolean,
  smtp_authorized boolean,
  send_bcc_to jsonb,
  signature jsonb,
  permitted_users jsonb,
  use_global_email boolean,
  email_provider text,
  imap_type text,
  imap_host jsonb,
  imap_port jsonb,
  imap_username jsonb,
  imap_password jsonb,
  imap_ssl boolean,
  smtp_host jsonb,
  smtp_port jsonb,
  smtp_username jsonb,
  smtp_password jsonb,
  smtp_ssl boolean,
  deleted boolean,
  created_at timestamptz,
  updated_at timestamptz
);

CREATE TABLE IF NOT EXISTS cubagem_master_items (
  id integer,
  item_name text,
  default_m3 numeric,
  item_value integer,
  created_at timestamptz,
  updated_at timestamptz
);

